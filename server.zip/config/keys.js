module.exports = {
    mongoURI:
      "mongodb+srv://Bp_db:bp_db@cluster0-eigwa.gcp.mongodb.net/<dbname>?retryWrites=true&w=majority",
      secretOrkey: "secret",
  };