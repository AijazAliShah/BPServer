
var PrivateKey = 'BUSINESSPLUGIN';
export default PrivateKey